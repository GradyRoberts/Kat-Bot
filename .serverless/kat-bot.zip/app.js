import 'dotenv/config';
import express from 'express';
import {
  InteractionType,
  InteractionResponseType,
} from 'discord-interactions';
import { VerifyDiscordRequest, DiscordRequest, getRandomEmoji } from './utils.js';

// Create an express app
const app = express();

// Parse request body and verifies incoming requests using discord-interactions package
app.use(express.json({ verify: VerifyDiscordRequest(process.env.PUBLIC_KEY) }));


/**
 * Interactions endpoint URL where Discord will send HTTP requests
 */
app.post('/interactions', async function (req, res) {
  // Interaction type, data, and metadata
  const { type, token, id, data } = req.body;

  /**
   * Handle verification requests
   */
  if (type === InteractionType.PING) {
    return res.send({ type: InteractionResponseType.PONG });
  }

  /**
   * Handle slash command requests
   * See https://discord.com/developers/docs/interactions/application-commands#slash-commands
   */
  const { name } = data;
  if (type === InteractionType.APPLICATION_COMMAND) {
    if (name === 'test') {
      // Send a message into the channel where command was triggered from
      console.log(req);
      return res.send({
        type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
        data: {
          // Fetches a random emoji to send from a helper function
          content: '<@163032275074678784> : hello world! ' + getRandomEmoji(),
        },
      });
    } else if (name === 'mention_voice') {
      const { options } = data;
      const channel_id = options[0]['value'];
      const message = options[1]['value'];
      
      return res.send({
        type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
        data: {
          content: `Channel: ${channel_id}, Message: ${message}`,
        },
      });

    } else if (name === 'mention_event') {

    }
  } else if (type === InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE) {
    if (name === 'mention_event') {
      // 1. Get list of events

      // 2. Return events as options
      const autocompleteOptions = ['Hello', 'World', 'Discord', 'Bot'];

      // may be able to just res.send
      await DiscordRequest(`interactions/${id}/${token}/callback`, {
        type: InteractionResponseType.APPLICATION_COMMAND_AUTOCOMPLETE_RESULT,
        data: {
          choices: autocompleteOptions.map((option) => ({
            name: option,
            value: option,
          })),
        },
      });
    }

  }
});

export default app;